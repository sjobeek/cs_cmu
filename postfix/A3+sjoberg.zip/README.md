# cs_cmu
Homework assignments from CMU course Data Structures and Algorithms for Engineers

## Files:
### solver.c
This file contains the source code for my Postscript Calculator as well as the implementation of the Stack ADT.

It can be compiled with the command `gcc -Wall solver.c -o calc` then run with `calc.exe`

### report.docx
This file contains the report writeup, including discussion of the design decisions and program analysis. 