## Compilation
g++ --std=c++11 main.cpp GraphActors.cpp GraphActors.h LinkedList.cpp LinkedList.h -o sixdegrees

## Running
sixdegrees.exe